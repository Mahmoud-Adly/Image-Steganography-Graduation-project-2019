package history;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JSONHandler {

    private static JSONHandler instance;

    private JSONHandler() {
    }

    public static JSONHandler getInstance() {
        if (instance == null) {
            instance = new JSONHandler();
        }
        return instance;
    }

    public void writeJSONObject(SteganographyObject object) throws IOException {
        ArrayList<SteganographyObject> allObjects = getSavedJSONObjects();
        allObjects.add(object);

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        FileWriter writer = new FileWriter("history.json");
        gson.toJson(allObjects, writer);
        writer.flush();
        writer.close();
    }

    public ArrayList<SteganographyObject> getSavedJSONObjects() throws FileNotFoundException, IOException {
        File file = new File("history.json");
        if(!file.exists())
           file.createNewFile();
        FileReader fileReader = new FileReader(file);
        Gson gson = new Gson();
        JsonReader reader;
        Type stegType = new TypeToken<ArrayList<SteganographyObject>>() {
        }.getType();
        reader = new JsonReader(fileReader);
        ArrayList<SteganographyObject> objects = gson.fromJson(fileReader, stegType);
        if(objects == null) objects = new ArrayList<>();
        reader.close();
        return objects;
    }

    void clearHistory() {
       File file = new File("history.json");
       if(file.exists()) {
           file.delete();
       }
    }

}
