package history;

import java.awt.Dimension;

public class SteganographyObject {

    private String inputImageFilePath;
    private double inputImageFileSize;
    private Dimension inputImageDimension;

    private String inputTextFilePath;
    private double inputTextFileSize;

    
    private String outputImageFilePath;
    private double outputImageFileSize;
    
    private String embedPassword;
    private double PSNR;

    public SteganographyObject() {
    }
    
    public void setInputImageFilePath(String inputImageFilePath) {
        this.inputImageFilePath = inputImageFilePath;
    }
    
    
    @Override
    public String toString() {
        return "[Input Image Path: " + this.getInputImageFilePath() + "]";
    }

    /**
     * @return the inputImageFilePath
     */
    public String getInputImageFilePath() {
        return inputImageFilePath;
    }

    /**
     * @return the inputImageFileSize
     */
    public double getInputImageFileSize() {
        return inputImageFileSize;
    }

    /**
     * @param inputImageFileSize the inputImageFileSize to set
     */
    public void setInputImageFileSize(double inputImageFileSize) {
        this.inputImageFileSize = inputImageFileSize;
    }

    /**
     * @return the inputImageDimension
     */
    public Dimension getInputImageDimension() {
        return inputImageDimension;
    }

    /**
     * @param inputImageDimension the inputImageDimension to set
     */
    public void setInputImageDimension(Dimension inputImageDimension) {
        this.inputImageDimension = inputImageDimension;
    }

    /**
     * @return the inputTextFilePath
     */
    public String getInputTextFilePath() {
        return inputTextFilePath;
    }

    /**
     * @param inputTextFilePath the inputTextFilePath to set
     */
    public void setInputTextFilePath(String inputTextFilePath) {
        this.inputTextFilePath = inputTextFilePath;
    }

    /**
     * @return the inputTextFileSize
     */
    public double getInputTextFileSize() {
        return inputTextFileSize;
    }

    /**
     * @param inputTextFileSize the inputTextFileSize to set
     */
    public void setInputTextFileSize(double inputTextFileSize) {
        this.inputTextFileSize = inputTextFileSize;
    }

    /**
     * @return the embedPassword
     */
    public String getEmbedPassword() {
        return embedPassword;
    }

    /**
     * @param embedPassword the embedPassword to set
     */
    public void setEmbedPassword(String embedPassword) {
        this.embedPassword = embedPassword;
    }

    /**
     * @return the outputImageFilePath
     */
    public String getOutputImageFilePath() {
        return outputImageFilePath;
    }

    /**
     * @param outputImageFilePath the outputImageFilePath to set
     */
    public void setOutputImageFilePath(String outputImageFilePath) {
        this.outputImageFilePath = outputImageFilePath;
    }

    /**
     * @return the outputImageFileSize
     */
    public double getOutputImageFileSize() {
        return outputImageFileSize;
    }

    /**
     * @param outputImageFileSize the outputImageFileSize to set
     */
    public void setOutputImageFileSize(double outputImageFileSize) {
        this.outputImageFileSize = outputImageFileSize;
    }

    /**
     * @return the PSNR
     */
    public double getPSNR() {
        return PSNR;
    }

    /**
     * @param PSNR the PSNR to set
     */
    public void setPSNR(double PSNR) {
        this.PSNR = PSNR;
    }

}
