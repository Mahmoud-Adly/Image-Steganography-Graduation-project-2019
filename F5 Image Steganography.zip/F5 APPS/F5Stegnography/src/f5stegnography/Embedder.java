/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package f5stegnography;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringBufferInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class Embedder {

    private static File inFile;
    private static File outFile;
    private static File embedFile;
    private static FileOutputStream dataOutStream;
    private static Image image;
    private static MJpegEncoder jpg;
    

    public static String embed(String embMsgFile, String inFileName, String outFileName, String password) {
        outFile = new File(outFileName); //identify output file
        inFile = new File(inFileName);
        String PSNRValue = "";
        //embedFile = new File(embMsgFile);
        //String password = "abc123";
        if (inFile.exists()) {
            try {
                dataOutStream = new FileOutputStream(outFile);
                image = Toolkit.getDefaultToolkit().getImage(inFileName);
                jpg = new MJpegEncoder(image, 80, dataOutStream, "comment");
                //jpg.Compress(new FileInputStream(embedFile), password);
                jpg.Compress(new StringBufferInputStream(embMsgFile), password);
                
                //jpg.Compress();
                dataOutStream.close();
//------------------------  PNSR ------------ Claculate --------------------------------------
                BufferedImage im1 = ImageIO.read(inFile);
                BufferedImage im2 = ImageIO.read(outFile);
                Psnr PSNR = new Psnr();
                PSNRValue = PSNR.PSNR(im1, im2);
//--------------------------------------------------------------------------------------------

            } catch (FileNotFoundException ex) {
                //catch clause not set
            } catch (IOException ex) {
                Logger.getLogger(Embedder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return PSNRValue;
    }
}
