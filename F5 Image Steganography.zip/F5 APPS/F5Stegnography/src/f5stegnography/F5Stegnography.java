/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package f5stegnography;

/**
 *
 * @author Mahmoud Adly
 */
public class F5Stegnography {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                MainView window = new MainView();
                window.setTitle("F5 Stegnography");
                window.setVisible(true);
            }
        });

        // Embedder.embed(embFileName, inFileName, outFileName);
        //Extractor.extract(outFileName);
    }

}
